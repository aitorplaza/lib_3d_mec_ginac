#define breaks_wheelL_n_rows 1
#define breaks_wheelL_n_cols 19
extern double * _breaks_wheelL ;
extern void Init_breaks_wheelL ( );
extern void Done_breaks_wheelL ( );
extern double * breaks_wheelL ( );
