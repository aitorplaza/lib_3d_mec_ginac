extern void get_spline_coefs (double * param, int pos_a, double * coefs, double * breaks, double u, int length_breaks, int rows_coefs);
