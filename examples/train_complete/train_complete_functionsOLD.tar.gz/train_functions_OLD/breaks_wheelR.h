#define breaks_wheelR_n_rows 1
#define breaks_wheelR_n_cols 19
extern double * _breaks_wheelR ;
extern void Init_breaks_wheelR ( );
extern void Done_breaks_wheelR ( );
extern double * breaks_wheelR ( );
