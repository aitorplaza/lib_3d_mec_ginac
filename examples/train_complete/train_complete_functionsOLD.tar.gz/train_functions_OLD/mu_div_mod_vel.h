//extern void mu_div_mod_vel (double * vel_ms, double * mu_V); 
extern double mu_div_mod_vel (double vel_ms); 
