#define coefs_wheelL_n_rows 18
#define coefs_wheelL_n_cols 4
extern double * _coefs_wheelL ;
extern void Init_coefs_wheelL ( );
extern void Done_coefs_wheelL ( );
extern double * coefs_wheelL ( );
