#define breaks_rail_n_rows 1
#define breaks_rail_n_cols 15
extern double * _breaks_rail;
extern void Init_breaks_rail ( );
extern void Done_breaks_rail ( );
extern double * breaks_rail ( );

