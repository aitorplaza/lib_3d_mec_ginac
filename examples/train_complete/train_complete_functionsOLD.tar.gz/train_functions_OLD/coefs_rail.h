#define coefs_rail_n_rows 14
#define coefs_rail_n_cols 4
extern double * _coefs_rail ;
extern void Init_coefs_rail ( );
extern void Done_coefs_rail ( );
extern double * coefs_rail ( );
