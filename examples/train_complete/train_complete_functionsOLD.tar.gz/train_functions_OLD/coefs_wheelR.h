#define coefs_wheelR_n_rows 18
#define coefs_wheelR_n_cols 4
extern double * _coefs_wheelR ;
extern void Init_coefs_wheelR ( );
extern void Done_coefs_wheelR ( );
extern double * coefs_wheelR ( );
