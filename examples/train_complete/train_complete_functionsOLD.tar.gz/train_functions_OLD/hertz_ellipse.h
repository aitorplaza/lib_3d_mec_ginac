extern void hertz_ellipse (double * param, int pos_a, int pos_E, double * output, int pos_r1x, int pos_N, double * T_Hertz, int T_hertz_rows);

