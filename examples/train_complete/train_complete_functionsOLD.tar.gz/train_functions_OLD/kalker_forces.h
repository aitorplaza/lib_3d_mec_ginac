extern void kalker_forces (double * output, int pos_vx, double * param, int pos_c11, int pos_a, int pos_G, double * inputs, int pos_fx);
