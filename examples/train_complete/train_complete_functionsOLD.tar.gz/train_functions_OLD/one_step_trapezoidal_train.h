extern void one_step_trapezoidal_train (double delta_t, double * q, double *dq);
