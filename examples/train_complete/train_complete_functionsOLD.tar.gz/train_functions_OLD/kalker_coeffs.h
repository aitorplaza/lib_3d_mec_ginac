extern void kalker_coeffs (double * T_kalker, int T_kalker_rows,  double * param, int pos_c11, int pos_a, int pos_nu);
