  // Model provided by IngeTEAM


  Output();

  inputs[1] = mu_div_mod_vel(_Output[0]);
  inputs[2] = mu_div_mod_vel(_Output[1]);
  inputs[3] = _Output[2];
  inputs[4] = _Output[3];


