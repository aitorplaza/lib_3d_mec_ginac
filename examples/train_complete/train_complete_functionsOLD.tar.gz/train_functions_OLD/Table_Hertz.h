#define Table_Hertz_n_rows 359
#define Table_Hertz_n_cols 3
extern double * _Table_Hertz ;
extern void Init_Table_Hertz ( );
extern void Done_Table_Hertz ( );
extern double * Table_Hertz ( );
