#define Table_Kalker_n_rows 19
#define Table_Kalker_n_cols 12
extern double * _Table_Kalker ;
extern void Init_Table_Kalker ( );
extern void Done_Table_Kalker ( );
extern double * Table_Kalker ( );
