#!/bin/bash

# delete files comming from train functions
rm -f Output.*
rm -f mu_div_mod_vel.*
rm -f get_spline_coefs.*
rm -f breaks_rail.*
rm -f breaks_wheelL.*
rm -f breaks_wheelR.*
rm -f coefs_rail.*
rm -f coefs_wheelL.*
rm -f coefs_wheelR.*
rm -f Initial_position_velocity_with_splines.*
rm -f hertz_ellipse.* 
rm -f Table_Hertz.*
rm -f kalker_coeffs.* 
rm -f Table_Kalker.*
rm -f kalker_forces.*   

rm -f one_step_trapezoidal_q_train.*
rm -f c_s_func_continuous_train.c
rm -f c_s_func_discrete_train.c
rm -f direct_dynamics_lin_alg_train.c
rm -f Includes_train.c
rm -f Integration_Trapezoidal_train.c
rm -f kalkers_forces_calculation.c
rm -f main_numeric_train.c
rm -f mu_div_mod_vel_sliding_vel.c
rm -f one_step_trapezoidal_q_train.c
rm -f one_step_trapezoidal_q_train.h
rm -f spline_tables.c
rm -f spline_tables_functions.c
rm -f spline_wheel_and_rail_profile.c

rm -f *.*~


