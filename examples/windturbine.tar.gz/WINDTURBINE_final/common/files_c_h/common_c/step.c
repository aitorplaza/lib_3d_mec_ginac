
double step(double a)
{
if (a>=0.0)
        return 1.;
else
        return 0.;
}

