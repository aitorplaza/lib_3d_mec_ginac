

double step(double a);
