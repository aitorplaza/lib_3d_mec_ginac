/* FREE Initialize.c */
Done_q (  );
Done_dq (  );
Done_ddq (  );
Done_unknowns (  );
#ifdef INPUTS
Done_inputs (  );
#endif
Done_param (  );
