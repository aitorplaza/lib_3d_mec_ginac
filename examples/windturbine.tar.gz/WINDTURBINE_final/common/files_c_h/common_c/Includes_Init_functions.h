/* Coord q */
/* #ifdef COORD_DEP */
/*all code is common because the Initial NR*/ 
/*new for coord indep*/

#include "PhiInit.h"
#include "PhiInit_q.h"
#include "BetaInit.h"
#include "dPhiInit_dq.h"

/*#endif*/

/* Coord z */
/*#ifdef COORD_IND
#endif*/
