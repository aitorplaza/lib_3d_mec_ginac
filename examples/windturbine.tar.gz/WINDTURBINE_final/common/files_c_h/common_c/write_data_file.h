/*----------data_file.h lib3D_MEC exported-----------*/

extern void write_data_file(FILE * data_file);
extern void write_data_file_header(FILE * data_file);
