#include "stdio.h"
extern void read_config_file(void);
