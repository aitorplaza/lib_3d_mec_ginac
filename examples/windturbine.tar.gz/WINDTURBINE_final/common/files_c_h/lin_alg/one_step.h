/*extern double	_Inv_Phi_d[Phi_n_rows * Phi_n_rows] ;*/
