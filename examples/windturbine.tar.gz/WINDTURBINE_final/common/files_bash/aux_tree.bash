#!/bin/bash

mkdir GENERATED_files_dat/

mkdir GENERATED_files_bin/

mkdir GENERATED_files_maple/
#mkdir GENERATED_files_maple/c
#mkdir GENERATED_files_maple/h
mkdir GENERATED_files_log
#mkdir GENERATED_files_maple/mpl

mkdir GENERATED_files_matlab/

mkdir GENERATED_files_objects/

mkdir GENERATED_files_osg/
mkdir GENERATED_files_osg/cpp
mkdir GENERATED_files_osg/h

mkdir GENERATED_files_latex/
mkdir GENERATED_files_latex/aux
mkdir GENERATED_files_latex/dvi
mkdir GENERATED_files_latex/eps
mkdir GENERATED_files_latex/dot
#mkdir GENERATED_files_latex/log
mkdir GENERATED_files_latex/psfrag

mkdir GENERATED_files_process_c_h/

mkdir GENERATED_files_graphics/

mkdir GENERATED_OSG_bin/
mkdir GENERATED_OSG_bin/solids

