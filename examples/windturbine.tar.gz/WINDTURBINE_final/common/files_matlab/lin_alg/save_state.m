state=state+1;
t_all(state)=time;
q_all(state,:) =q;
dq_all(state,:)=dq; 