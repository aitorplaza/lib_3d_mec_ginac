if strcmp(TIME,'ON')
    average=toc/(t_end/delta_t)
else
    USER_output_file;
end