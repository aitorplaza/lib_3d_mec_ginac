#define dPhi_dq_n_rows 6
#define dPhi_dq_n_cols 55
extern double * _dPhi_dq;
extern void Init_dPhi_dq ( ); 
extern void Done_dPhi_dq ( ); 
extern double * dPhi_dq ( ) ;
