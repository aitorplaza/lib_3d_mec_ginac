#include <stdlib.h>
#include "gen_coord.h"

#define x2 0.0
#define y2 0.0
#define c2 0.0
#define x3 0.0
#define y3 0.0
#define z3 0.0
#define a3 0.0
#define b3 0.0
#define c3 0.0
#define x4 0.0
#define y4 0.0
#define z4 0.0
#define a4 0.0
#define b4 0.0
#define c4 0.0
#define x5 0.0
#define y5 0.0
#define z5 0.0
#define b5 0.0
#define c5 0.0
#define a6 0.0
#define b6 0.0
#define c6 0.0
#define a7 0.0
#define xSun 0.0
#define ySun 0.0
#define zSun 0.0
#define bSun 0.0
#define cSun 0.0
#define xPla1 0.0
#define yPla1 0.0
#define zPla1 0.0
#define bPla1 0.0
#define cPla1 0.0
#define xPla2 0.0
#define yPla2 0.0
#define zPla2 0.0
#define bPla2 0.0
#define cPla2 0.0
#define xPla3 0.0
#define yPla3 0.0
#define zPla3 0.0
#define bPla3 0.0
#define cPla3 0.0
#define xSecSt 0.0
#define ySecSt 0.0
#define zSecSt 0.0
#define bSecSt 0.0
#define cSecSt 0.0
#define aSun 0.0
#define aPla1 0.0
#define aPla2 0.0
#define aPla3 0.0
#define aSecSt 0.0
#define a5 0.0

double * q=NULL; 

void Init_q_values ( void )
{
q[0]=x2;
q[1]=y2;
q[2]=c2;
q[3]=x3;
q[4]=y3;
q[5]=z3;
q[6]=a3;
q[7]=b3;
q[8]=c3;
q[9]=x4;
q[10]=y4;
q[11]=z4;
q[12]=a4;
q[13]=b4;
q[14]=c4;
q[15]=x5;
q[16]=y5;
q[17]=z5;
q[18]=b5;
q[19]=c5;
q[20]=a6;
q[21]=b6;
q[22]=c6;
q[23]=a7;
q[24]=xSun;
q[25]=ySun;
q[26]=zSun;
q[27]=bSun;
q[28]=cSun;
q[29]=xPla1;
q[30]=yPla1;
q[31]=zPla1;
q[32]=bPla1;
q[33]=cPla1;
q[34]=xPla2;
q[35]=yPla2;
q[36]=zPla2;
q[37]=bPla2;
q[38]=cPla2;
q[39]=xPla3;
q[40]=yPla3;
q[41]=zPla3;
q[42]=bPla3;
q[43]=cPla3;
q[44]=xSecSt;
q[45]=ySecSt;
q[46]=zSecSt;
q[47]=bSecSt;
q[48]=cSecSt;
q[49]=aSun;
q[50]=aPla1;
q[51]=aPla2;
q[52]=aPla3;
q[53]=aSecSt;
q[54]=a5;
}

void Init_q ( )
{
 q = malloc ( n_gen_coord * sizeof(double) );
 {int i;
  for ( i = 0 ; i < n_gen_coord ; i++ ) {q[i]=0.0;}
 }
}

void Done_q( ) 
{
if ( q != NULL) 
free ( q ); 
q = NULL; 
}

void Reallocate_q( double * user_q ) 
{
q = user_q; 
}

