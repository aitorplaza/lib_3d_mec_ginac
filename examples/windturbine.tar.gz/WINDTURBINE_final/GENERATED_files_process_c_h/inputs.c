#include <stdlib.h>
#include "inputs.h"

#define FHUBx 0.0000000000000000e+00
#define FHUBy 0.0000000000000000e+00
#define FHUBz 0.0000000000000000e+00
#define MHUBx 0.0000000000000000e+00
#define MHUBy 0.0000000000000000e+00
#define MHUBz 0.0000000000000000e+00
#define FBRAz 0.0000000000000000e+00
#define TGENx 0.0000000000000000e+00
#define FBearing1x 0.0000000000000000e+00
#define FBearing1y 0.0000000000000000e+00
#define FBearing1z 0.0000000000000000e+00
#define MBearing1x 0.0000000000000000e+00
#define MBearing1y 0.0000000000000000e+00
#define MBearing1z 0.0000000000000000e+00
#define FBearing2x 0.0000000000000000e+00
#define FBearing2y 0.0000000000000000e+00
#define FBearing2z 0.0000000000000000e+00
#define MBearing2x 0.0000000000000000e+00
#define MBearing2y 0.0000000000000000e+00
#define MBearing2z 0.0000000000000000e+00
#define FBearing3x 0.0000000000000000e+00
#define FBearing3y 0.0000000000000000e+00
#define FBearing3z 0.0000000000000000e+00
#define MBearing3x 0.0000000000000000e+00
#define MBearing3y 0.0000000000000000e+00
#define MBearing3z 0.0000000000000000e+00
#define FGBBearing1x 0.0000000000000000e+00
#define FGBBearing1y 0.0000000000000000e+00
#define FGBBearing1z 0.0000000000000000e+00
#define MGBBearing1x 0.0000000000000000e+00
#define MGBBearing1y 0.0000000000000000e+00
#define MGBBearing1z 0.0000000000000000e+00
#define FGBBearing2x 0.0000000000000000e+00
#define FGBBearing2y 0.0000000000000000e+00
#define FGBBearing2z 0.0000000000000000e+00
#define MGBBearing2x 0.0000000000000000e+00
#define MGBBearing2y 0.0000000000000000e+00
#define MGBBearing2z 0.0000000000000000e+00
#define FGBBearing3x 0.0000000000000000e+00
#define FGBBearing3y 0.0000000000000000e+00
#define FGBBearing3z 0.0000000000000000e+00
#define MGBBearing3x 0.0000000000000000e+00
#define MGBBearing3y 0.0000000000000000e+00
#define MGBBearing3z 0.0000000000000000e+00
#define FGBBearing4x 0.0000000000000000e+00
#define FGBBearing4y 0.0000000000000000e+00
#define FGBBearing4z 0.0000000000000000e+00
#define MGBBearing4x 0.0000000000000000e+00
#define MGBBearing4y 0.0000000000000000e+00
#define MGBBearing4z 0.0000000000000000e+00
#define FGBBearing5x 0.0000000000000000e+00
#define FGBBearing5y 0.0000000000000000e+00
#define FGBBearing5z 0.0000000000000000e+00
#define MGBBearing5x 0.0000000000000000e+00
#define MGBBearing5y 0.0000000000000000e+00
#define MGBBearing5z 0.0000000000000000e+00
#define FGBBearing6x 0.0000000000000000e+00
#define FGBBearing6y 0.0000000000000000e+00
#define FGBBearing6z 0.0000000000000000e+00
#define MGBBearing6x 0.0000000000000000e+00
#define MGBBearing6y 0.0000000000000000e+00
#define MGBBearing6z 0.0000000000000000e+00
#define FGBBearing7x 0.0000000000000000e+00
#define FGBBearing7y 0.0000000000000000e+00
#define FGBBearing7z 0.0000000000000000e+00
#define MGBBearing7x 0.0000000000000000e+00
#define MGBBearing7y 0.0000000000000000e+00
#define MGBBearing7z 0.0000000000000000e+00
#define FGBBearing8x 0.0000000000000000e+00
#define FGBBearing8y 0.0000000000000000e+00
#define FGBBearing8z 0.0000000000000000e+00
#define MGBBearing8x 0.0000000000000000e+00
#define MGBBearing8y 0.0000000000000000e+00
#define MGBBearing8z 0.0000000000000000e+00
#define FGBBearing9x 0.0000000000000000e+00
#define FGBBearing9y 0.0000000000000000e+00
#define FGBBearing9z 0.0000000000000000e+00
#define MGBBearing9x 0.0000000000000000e+00
#define MGBBearing9y 0.0000000000000000e+00
#define MGBBearing9z 0.0000000000000000e+00

double * inputs=NULL; 

void Init_inputs_values ( void )
{
inputs[0]=FHUBx;
inputs[1]=FHUBy;
inputs[2]=FHUBz;
inputs[3]=MHUBx;
inputs[4]=MHUBy;
inputs[5]=MHUBz;
inputs[6]=FBRAz;
inputs[7]=TGENx;
inputs[8]=FBearing1x;
inputs[9]=FBearing1y;
inputs[10]=FBearing1z;
inputs[11]=MBearing1x;
inputs[12]=MBearing1y;
inputs[13]=MBearing1z;
inputs[14]=FBearing2x;
inputs[15]=FBearing2y;
inputs[16]=FBearing2z;
inputs[17]=MBearing2x;
inputs[18]=MBearing2y;
inputs[19]=MBearing2z;
inputs[20]=FBearing3x;
inputs[21]=FBearing3y;
inputs[22]=FBearing3z;
inputs[23]=MBearing3x;
inputs[24]=MBearing3y;
inputs[25]=MBearing3z;
inputs[26]=FGBBearing1x;
inputs[27]=FGBBearing1y;
inputs[28]=FGBBearing1z;
inputs[29]=MGBBearing1x;
inputs[30]=MGBBearing1y;
inputs[31]=MGBBearing1z;
inputs[32]=FGBBearing2x;
inputs[33]=FGBBearing2y;
inputs[34]=FGBBearing2z;
inputs[35]=MGBBearing2x;
inputs[36]=MGBBearing2y;
inputs[37]=MGBBearing2z;
inputs[38]=FGBBearing3x;
inputs[39]=FGBBearing3y;
inputs[40]=FGBBearing3z;
inputs[41]=MGBBearing3x;
inputs[42]=MGBBearing3y;
inputs[43]=MGBBearing3z;
inputs[44]=FGBBearing4x;
inputs[45]=FGBBearing4y;
inputs[46]=FGBBearing4z;
inputs[47]=MGBBearing4x;
inputs[48]=MGBBearing4y;
inputs[49]=MGBBearing4z;
inputs[50]=FGBBearing5x;
inputs[51]=FGBBearing5y;
inputs[52]=FGBBearing5z;
inputs[53]=MGBBearing5x;
inputs[54]=MGBBearing5y;
inputs[55]=MGBBearing5z;
inputs[56]=FGBBearing6x;
inputs[57]=FGBBearing6y;
inputs[58]=FGBBearing6z;
inputs[59]=MGBBearing6x;
inputs[60]=MGBBearing6y;
inputs[61]=MGBBearing6z;
inputs[62]=FGBBearing7x;
inputs[63]=FGBBearing7y;
inputs[64]=FGBBearing7z;
inputs[65]=MGBBearing7x;
inputs[66]=MGBBearing7y;
inputs[67]=MGBBearing7z;
inputs[68]=FGBBearing8x;
inputs[69]=FGBBearing8y;
inputs[70]=FGBBearing8z;
inputs[71]=MGBBearing8x;
inputs[72]=MGBBearing8y;
inputs[73]=MGBBearing8z;
inputs[74]=FGBBearing9x;
inputs[75]=FGBBearing9y;
inputs[76]=FGBBearing9z;
inputs[77]=MGBBearing9x;
inputs[78]=MGBBearing9y;
inputs[79]=MGBBearing9z;
}

void Init_inputs ( )
{
 inputs = malloc ( n_inputs * sizeof(double) );
 {int i;
  for ( i = 0 ; i < n_inputs ; i++ ) {inputs[i]=0.0;}
 }
}

void Done_inputs( ) 
{
if ( inputs != NULL) 
free ( inputs ); 
inputs = NULL; 
}

void Reallocate_inputs( double * user_inputs ) 
{
inputs = user_inputs; 
}

