#define dPhiInit_dq_n_rows 55
#define dPhiInit_dq_n_cols 55
extern double * _dPhiInit_dq;
extern void Init_dPhiInit_dq ( ); 
extern void Done_dPhiInit_dq ( ); 
extern double * dPhiInit_dq ( ) ;
