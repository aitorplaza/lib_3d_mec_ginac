#include <stdlib.h>
#include "gen_accel.h"

#define ddx2 0.0
#define ddy2 0.0
#define ddc2 0.0
#define ddx3 0.0
#define ddy3 0.0
#define ddz3 0.0
#define dda3 0.0
#define ddb3 0.0
#define ddc3 0.0
#define ddx4 0.0
#define ddy4 0.0
#define ddz4 0.0
#define dda4 0.0
#define ddb4 0.0
#define ddc4 0.0
#define ddx5 0.0
#define ddy5 0.0
#define ddz5 0.0
#define ddb5 0.0
#define ddc5 0.0
#define dda6 0.0
#define ddb6 0.0
#define ddc6 0.0
#define dda7 0.0
#define ddxSun 0.0
#define ddySun 0.0
#define ddzSun 0.0
#define ddbSun 0.0
#define ddcSun 0.0
#define ddxPla1 0.0
#define ddyPla1 0.0
#define ddzPla1 0.0
#define ddbPla1 0.0
#define ddcPla1 0.0
#define ddxPla2 0.0
#define ddyPla2 0.0
#define ddzPla2 0.0
#define ddbPla2 0.0
#define ddcPla2 0.0
#define ddxPla3 0.0
#define ddyPla3 0.0
#define ddzPla3 0.0
#define ddbPla3 0.0
#define ddcPla3 0.0
#define ddxSecSt 0.0
#define ddySecSt 0.0
#define ddzSecSt 0.0
#define ddbSecSt 0.0
#define ddcSecSt 0.0
#define ddaSun 0.0
#define ddaPla1 0.0
#define ddaPla2 0.0
#define ddaPla3 0.0
#define ddaSecSt 0.0
#define dda5 0.0

double * ddq=NULL; 

void Init_ddq_values ( void )
{
ddq[0]=ddx2;
ddq[1]=ddy2;
ddq[2]=ddc2;
ddq[3]=ddx3;
ddq[4]=ddy3;
ddq[5]=ddz3;
ddq[6]=dda3;
ddq[7]=ddb3;
ddq[8]=ddc3;
ddq[9]=ddx4;
ddq[10]=ddy4;
ddq[11]=ddz4;
ddq[12]=dda4;
ddq[13]=ddb4;
ddq[14]=ddc4;
ddq[15]=ddx5;
ddq[16]=ddy5;
ddq[17]=ddz5;
ddq[18]=ddb5;
ddq[19]=ddc5;
ddq[20]=dda6;
ddq[21]=ddb6;
ddq[22]=ddc6;
ddq[23]=dda7;
ddq[24]=ddxSun;
ddq[25]=ddySun;
ddq[26]=ddzSun;
ddq[27]=ddbSun;
ddq[28]=ddcSun;
ddq[29]=ddxPla1;
ddq[30]=ddyPla1;
ddq[31]=ddzPla1;
ddq[32]=ddbPla1;
ddq[33]=ddcPla1;
ddq[34]=ddxPla2;
ddq[35]=ddyPla2;
ddq[36]=ddzPla2;
ddq[37]=ddbPla2;
ddq[38]=ddcPla2;
ddq[39]=ddxPla3;
ddq[40]=ddyPla3;
ddq[41]=ddzPla3;
ddq[42]=ddbPla3;
ddq[43]=ddcPla3;
ddq[44]=ddxSecSt;
ddq[45]=ddySecSt;
ddq[46]=ddzSecSt;
ddq[47]=ddbSecSt;
ddq[48]=ddcSecSt;
ddq[49]=ddaSun;
ddq[50]=ddaPla1;
ddq[51]=ddaPla2;
ddq[52]=ddaPla3;
ddq[53]=ddaSecSt;
ddq[54]=dda5;
}

void Init_ddq ( )
{
 ddq = malloc ( n_gen_accel * sizeof(double) );
 {int i;
  for ( i = 0 ; i < n_gen_accel ; i++ ) {ddq[i]=0.0;}
 }
}

void Done_ddq( ) 
{
if ( ddq != NULL) 
free ( ddq ); 
ddq = NULL; 
}

void Reallocate_ddq( double * user_ddq ) 
{
ddq = user_ddq; 
}

