#include <stdlib.h>
#include "gen_vel.h"

#define dx2 0.0
#define dy2 0.0
#define dc2 0.0
#define dx3 0.0
#define dy3 0.0
#define dz3 0.0
#define da3 0.0
#define db3 0.0
#define dc3 0.0
#define dx4 0.0
#define dy4 0.0
#define dz4 0.0
#define da4 0.0
#define db4 0.0
#define dc4 0.0
#define dx5 0.0
#define dy5 0.0
#define dz5 0.0
#define db5 0.0
#define dc5 0.0
#define da6 0.0
#define db6 0.0
#define dc6 0.0
#define da7 0.0
#define dxSun 0.0
#define dySun 0.0
#define dzSun 0.0
#define dbSun 0.0
#define dcSun 0.0
#define dxPla1 0.0
#define dyPla1 0.0
#define dzPla1 0.0
#define dbPla1 0.0
#define dcPla1 0.0
#define dxPla2 0.0
#define dyPla2 0.0
#define dzPla2 0.0
#define dbPla2 0.0
#define dcPla2 0.0
#define dxPla3 0.0
#define dyPla3 0.0
#define dzPla3 0.0
#define dbPla3 0.0
#define dcPla3 0.0
#define dxSecSt 0.0
#define dySecSt 0.0
#define dzSecSt 0.0
#define dbSecSt 0.0
#define dcSecSt 0.0
#define daSun 0.0
#define daPla1 0.0
#define daPla2 0.0
#define daPla3 0.0
#define daSecSt 0.0
#define da5 0.0

double * dq=NULL; 

void Init_dq_values ( void )
{
dq[0]=dx2;
dq[1]=dy2;
dq[2]=dc2;
dq[3]=dx3;
dq[4]=dy3;
dq[5]=dz3;
dq[6]=da3;
dq[7]=db3;
dq[8]=dc3;
dq[9]=dx4;
dq[10]=dy4;
dq[11]=dz4;
dq[12]=da4;
dq[13]=db4;
dq[14]=dc4;
dq[15]=dx5;
dq[16]=dy5;
dq[17]=dz5;
dq[18]=db5;
dq[19]=dc5;
dq[20]=da6;
dq[21]=db6;
dq[22]=dc6;
dq[23]=da7;
dq[24]=dxSun;
dq[25]=dySun;
dq[26]=dzSun;
dq[27]=dbSun;
dq[28]=dcSun;
dq[29]=dxPla1;
dq[30]=dyPla1;
dq[31]=dzPla1;
dq[32]=dbPla1;
dq[33]=dcPla1;
dq[34]=dxPla2;
dq[35]=dyPla2;
dq[36]=dzPla2;
dq[37]=dbPla2;
dq[38]=dcPla2;
dq[39]=dxPla3;
dq[40]=dyPla3;
dq[41]=dzPla3;
dq[42]=dbPla3;
dq[43]=dcPla3;
dq[44]=dxSecSt;
dq[45]=dySecSt;
dq[46]=dzSecSt;
dq[47]=dbSecSt;
dq[48]=dcSecSt;
dq[49]=daSun;
dq[50]=daPla1;
dq[51]=daPla2;
dq[52]=daPla3;
dq[53]=daSecSt;
dq[54]=da5;
}

void Init_dq ( )
{
 dq = malloc ( n_gen_vel * sizeof(double) );
 {int i;
  for ( i = 0 ; i < n_gen_vel ; i++ ) {dq[i]=0.0;}
 }
}

void Done_dq( ) 
{
if ( dq != NULL) 
free ( dq ); 
dq = NULL; 
}

void Reallocate_dq( double * user_dq ) 
{
dq = user_dq; 
}

