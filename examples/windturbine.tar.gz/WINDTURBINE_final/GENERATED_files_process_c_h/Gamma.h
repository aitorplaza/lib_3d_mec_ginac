#define Gamma_n_rows 6
#define Gamma_n_cols 1
extern double * _Gamma;
extern void Init_Gamma ( ); 
extern void Done_Gamma ( ); 
extern double * Gamma ( ) ;
