/*{*/
  double t19;
  double t2;
  double t21;
  double t22;
  double t24;
  double t32;
  double t34;
  double t36;
  double t38;
  double t39;
  double t6;
  double t7;
  double t8;
  /*{*/
    t2 = LGr1*(a3-a4);
    t6 = pow(Z_Pla+Z_Sun,-0.1E1);
    t7 = t6*Z_Pla;
    t8 = LGr1*(a3-a4+aPla1)*t7;
    _Phi[0] = -t2-t8;
    _Phi[1] = -t2-LGr1*(a3+aPla2-a4)*t7;
    _Phi[2] = -t2-(a3-a4+aPla3)*LGr1*t7;
    _Phi[3] = -t2+t8+LGr1*aSun*t6*Z_Sun;
    t19 = pow(Z_SecSt2+Z_SecSt1,-0.1E1);
    t21 = pow(LGy1,0.2E1);
    t22 = pow(LGz1,0.2E1);
    t24 = pow(t21+t22,0.5);
    _Phi[4] = aSecSt*t19*Z_SecSt2*t24+t19*aSun*Z_SecSt1*t24;
    t32 = pow(Z_ThiSt2+Z_ThiSt1,-0.1E1);
    t34 = pow(LGz2-LGz1,0.2E1);
    t36 = pow(LGy1-LGy2,0.2E1);
    t38 = pow(t34+t36,0.5);
    t39 = t32*t38;
    _Phi[5] = aSecSt*Z_ThiSt1*t39+Z_ThiSt2*(a5-a4)*t39;
   /*}*/
 /*}*/

