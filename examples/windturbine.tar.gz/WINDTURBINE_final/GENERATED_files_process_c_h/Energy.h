#define Energy_n_rows 1
#define Energy_n_cols 1
extern double * _Energy;
extern void Init_Energy ( ); 
extern void Done_Energy ( ); 
extern double * Energy ( ) ;
