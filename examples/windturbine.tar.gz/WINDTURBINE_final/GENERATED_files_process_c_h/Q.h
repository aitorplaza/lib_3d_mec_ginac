#define Q_n_rows 55
#define Q_n_cols 1
extern double * _Q;
extern void Init_Q ( ); 
extern void Done_Q ( ); 
extern double * Q ( ) ;
