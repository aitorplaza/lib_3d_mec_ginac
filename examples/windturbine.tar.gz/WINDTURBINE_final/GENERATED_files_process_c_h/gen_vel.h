/*----------gen_vel.h lib3D_MEC expoted-----------*/

extern double * dq;
extern void Init_dq_values ( void );
extern void Init_dq ( void );
extern void Done_dq( void  );
extern void Reallocate_dq( double * user_dq );

#define n_gen_vel 55
