#define MXdPhi_dqZero_n_rows 61
#define MXdPhi_dqZero_n_cols 61
extern double * _MXdPhi_dqZero;
extern void Init_MXdPhi_dqZero ( ); 
extern void Done_MXdPhi_dqZero ( ); 
extern double * MXdPhi_dqZero ( ) ;
