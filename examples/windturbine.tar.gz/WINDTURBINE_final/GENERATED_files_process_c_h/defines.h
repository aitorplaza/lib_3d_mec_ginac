#define NEWTON_RAPHSON_TOLERANCE 1.0e-8 
#define UNKNOWNS
#define INPUTS
#define PHI
