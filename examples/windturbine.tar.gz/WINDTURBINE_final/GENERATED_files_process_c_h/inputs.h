/*----------inputs.h lib3D_MEC exported-----------*/

extern double * inputs;
extern void Init_inputs_values ( void );
extern void Init_inputs ( void  );
extern void Done_inputs( void );
extern void Reallocate_inputs( double * user_inputs );

#define n_inputs 80
