#define Phi_n_rows 6
#define Phi_n_cols 1
extern double * _Phi;
extern void Init_Phi ( ); 
extern void Done_Phi ( ); 
extern double * Phi ( ) ;
