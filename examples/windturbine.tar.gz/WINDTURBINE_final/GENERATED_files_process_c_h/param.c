#include <stdlib.h>
#include "param.h"

#define g 9.8000000000000007e+00
#define L2x 1.0000000000000000e+00
#define L2z 2.0000000000000000e+00
#define LS2x1 1.5000000000000000e+00
#define LS2y1 1.0000000000000000e+00
#define LS2z1 1.0000000000000000e+00
#define LS2x2 4.0000000000000000e+00
#define LS2x3 6.0000000000000000e+00
#define LS2y2 1.5000000000000000e+00
#define LS2y3 5.0000000000000000e-01
#define LS2z2 1.0000000000000000e+00
#define LB2x 2.5000000000000000e+00
#define LB2y 1.0000000000000000e+00
#define LB2z 2.5000000000000000e+00
#define b2 8.7266462611111109e-02
#define L3x1 2.0000000000000000e+00
#define L3x2 2.0000000000000000e+00
#define L4x 1.0000000000000000e+00
#define L4y 5.0000000000000000e-01
#define L4z 5.0000000000000000e-01
#define LS4x 5.0000000000000000e-01
#define LS4y 1.0000000000000000e+00
#define LS4z 1.0000000000000000e+00
#define L6x 1.0000000000000000e+00
#define LB5x 5.0000000000000000e-01
#define LB5y 5.0000000000000000e-01
#define LS7x1 1.0000000000000000e+00
#define LS7x2 3.0000000000000000e+00
#define LS7y1 1.0000000000000000e+00
#define LS7y2 1.0000000000000000e+00
#define LS7z 1.5000000000000000e+00
#define LGx1 2.5000000000000000e-01
#define LGx2 4.0000000000000002e-01
#define LGx3 5.0000000000000000e-01
#define LGx4 1.0000000000000000e+00
#define LGx5 5.0000000000000000e-01
#define LGx6 1.0000000000000000e+00
#define LGx7 5.0000000000000000e-01
#define LGx8 1.0000000000000000e+00
#define LGr1 2.5000000000000000e-01
#define LGy1 2.5000000000000000e-01
#define LGz1 2.5000000000000000e-01
#define LGy2 5.0000000000000000e-01
#define LGz2 5.0000000000000000e-01
#define Z_Ring 89.0
#define Z_Sun 16.0
#define Z_Pla 36.0
#define Z_SecSt1 90.0
#define Z_SecSt2 22.0
#define Z_ThiSt1 91.0
#define Z_ThiSt2 25.0
#define m2 1.0000000000000000e+00
#define mx2 0.0000000000000000e+00
#define my2 0.0000000000000000e+00
#define mz2 0.0000000000000000e+00
#define Ixx2 1.0000000000000000e+00
#define Ixy2 0.0000000000000000e+00
#define Iyy2 1.0000000000000000e+00
#define Ixz2 0.0000000000000000e+00
#define Izz2 1.0000000000000000e+00
#define Iyz2 0.0000000000000000e+00
#define m3 1.0000000000000000e+00
#define mx3 0.0000000000000000e+00
#define my3 0.0000000000000000e+00
#define mz3 0.0000000000000000e+00
#define Ixx3 1.0000000000000000e+00
#define Ixy3 0.0000000000000000e+00
#define Iyy3 1.0000000000000000e+00
#define Ixz3 0.0000000000000000e+00
#define Izz3 1.0000000000000000e+00
#define Iyz3 0.0000000000000000e+00
#define m4 1.0000000000000000e+00
#define mx4 0.0000000000000000e+00
#define my4 0.0000000000000000e+00
#define mz4 0.0000000000000000e+00
#define Ixx4 1.0000000000000000e+00
#define Ixy4 0.0000000000000000e+00
#define Iyy4 1.0000000000000000e+00
#define Ixz4 0.0000000000000000e+00
#define Izz4 1.0000000000000000e+00
#define Iyz4 0.0000000000000000e+00
#define m5 1.0000000000000000e+00
#define mx5 0.0000000000000000e+00
#define my5 0.0000000000000000e+00
#define mz5 0.0000000000000000e+00
#define Ixx5 1.0000000000000000e+00
#define Ixy5 0.0000000000000000e+00
#define Iyy5 1.0000000000000000e+00
#define Ixz5 0.0000000000000000e+00
#define Izz5 1.0000000000000000e+00
#define Iyz5 0.0000000000000000e+00
#define m6 1.0000000000000000e+00
#define mx6 0.0000000000000000e+00
#define my6 0.0000000000000000e+00
#define mz6 0.0000000000000000e+00
#define Ixx6 1.0000000000000000e+00
#define Ixy6 0.0000000000000000e+00
#define Iyy6 1.0000000000000000e+00
#define Ixz6 0.0000000000000000e+00
#define Izz6 1.0000000000000000e+00
#define Iyz6 0.0000000000000000e+00
#define m7 1.0000000000000000e+00
#define mx7 0.0000000000000000e+00
#define my7 0.0000000000000000e+00
#define mz7 0.0000000000000000e+00
#define Ixx7 1.0000000000000000e+00
#define Ixy7 0.0000000000000000e+00
#define Iyy7 1.0000000000000000e+00
#define Ixz7 0.0000000000000000e+00
#define Izz7 1.0000000000000000e+00
#define Iyz7 0.0000000000000000e+00
#define mSun 1.0000000000000000e+00
#define mxSun 0.0000000000000000e+00
#define mySun 0.0000000000000000e+00
#define mzSun 0.0000000000000000e+00
#define IxxSun 1.0000000000000000e+00
#define IxySun 0.0000000000000000e+00
#define IyySun 1.0000000000000000e+00
#define IxzSun 0.0000000000000000e+00
#define IzzSun 1.0000000000000000e+00
#define IyzSun 0.0000000000000000e+00
#define mPla1 1.0000000000000001e-01
#define mxPla1 0.0000000000000000e+00
#define myPla1 0.0000000000000000e+00
#define mzPla1 0.0000000000000000e+00
#define IxxPla1 1.0000000000000000e+00
#define IxyPla1 0.0000000000000000e+00
#define IyyPla1 1.0000000000000000e+00
#define IxzPla1 0.0000000000000000e+00
#define IzzPla1 1.0000000000000000e+00
#define IyzPla1 0.0000000000000000e+00
#define mPla2 1.0000000000000001e-01
#define mxPla2 0.0000000000000000e+00
#define myPla2 0.0000000000000000e+00
#define mzPla2 0.0000000000000000e+00
#define IxxPla2 1.0000000000000000e+00
#define IxyPla2 0.0000000000000000e+00
#define IyyPla2 1.0000000000000000e+00
#define IxzPla2 0.0000000000000000e+00
#define IzzPla2 1.0000000000000000e+00
#define IyzPla2 0.0000000000000000e+00
#define mPla3 1.0000000000000001e-01
#define mxPla3 0.0000000000000000e+00
#define myPla3 0.0000000000000000e+00
#define mzPla3 0.0000000000000000e+00
#define IxxPla3 1.0000000000000000e+00
#define IxyPla3 0.0000000000000000e+00
#define IyyPla3 1.0000000000000000e+00
#define IxzPla3 0.0000000000000000e+00
#define IzzPla3 1.0000000000000000e+00
#define IyzPla3 0.0000000000000000e+00
#define mSecSt 1.0000000000000000e+00
#define mxSecSt 0.0000000000000000e+00
#define mySecSt 0.0000000000000000e+00
#define mzSecSt 0.0000000000000000e+00
#define IxxSecSt 1.0000000000000000e+00
#define IxySecSt 0.0000000000000000e+00
#define IyySecSt 1.0000000000000000e+00
#define IxzSecSt 0.0000000000000000e+00
#define IzzSecSt 1.0000000000000000e+00
#define IyzSecSt 0.0000000000000000e+00
#define KF12x 1.0000000000000000e+04
#define KF12y 1.0000000000000000e+04
#define CF12x 3.0000000000000000e+00
#define CF12y 3.0000000000000000e+00
#define KM12z 2.2000000000000000e+02
#define CM12z 3.0000000000000000e+01
#define KF24x 1.0000000000000000e+04
#define KF24y 1.0000000000000000e+04
#define KF24z 1.0000000000000000e+04
#define CF24x 3.0000000000000000e+00
#define CF24y 3.0000000000000000e+00
#define CF24z 3.0000000000000000e+00
#define KF27x 1.0000000000000000e+04
#define KF27y 1.0000000000000000e+04
#define KF27z 1.0000000000000000e+04
#define CF27x 3.0000000000000000e+00
#define CF27y 3.0000000000000000e+00
#define CF27z 3.0000000000000000e+00
#define KFBearing1x 1.0000000000000000e+03
#define KFBearing1y 1.0000000000000000e+03
#define KFBearing1z 1.0000000000000000e+03
#define CFBearing1x 3.0000000000000000e+00
#define CFBearing1y 3.0000000000000000e+00
#define CFBearing1z 3.0000000000000000e+00
#define KMBearing1y 1.0000000000000000e+03
#define KMBearing1z 1.0000000000000000e+03
#define CMBearing1y 3.0000000000000000e+00
#define CMBearing1z 3.0000000000000000e+00
#define KFBearing2x 1.0000000000000000e+03
#define KFBearing2y 1.0000000000000000e+03
#define KFBearing2z 1.0000000000000000e+03
#define CFBearing2x 3.0000000000000000e+00
#define CFBearing2y 3.0000000000000000e+00
#define CFBearing2z 3.0000000000000000e+00
#define KMBearing2y 1.0000000000000000e+03
#define KMBearing2z 1.0000000000000000e+03
#define CMBearing2y 3.0000000000000000e+00
#define CMBearing2z 3.0000000000000000e+00
#define KFGBBearing4x 1.0000000000000000e+03
#define KFGBBearing4y 1.0000000000000000e+03
#define KFGBBearing4z 1.0000000000000000e+03
#define CFGBBearing4x 3.0000000000000000e+00
#define CFGBBearing4y 3.0000000000000000e+00
#define CFGBBearing4z 3.0000000000000000e+00
#define KMGBBearing4y 1.0000000000000000e+03
#define KMGBBearing4z 1.0000000000000000e+03
#define CMGBBearing4y 3.0000000000000000e+00
#define CMGBBearing4z 3.0000000000000000e+00
#define KFBearing3x 1.0000000000000000e+03
#define KFBearing3y 1.0000000000000000e+03
#define KFBearing3z 1.0000000000000000e+03
#define CFBearing3x 3.0000000000000000e+00
#define CFBearing3y 3.0000000000000000e+00
#define CFBearing3z 3.0000000000000000e+00
#define KMBearing3y 1.0000000000000000e+03
#define KMBearing3z 1.0000000000000000e+03
#define CMBearing3y 3.0000000000000000e+00
#define CMBearing3z 3.0000000000000000e+00
#define KFGBBearing9x 1.0000000000000000e+03
#define KFGBBearing9y 1.0000000000000000e+03
#define KFGBBearing9z 1.0000000000000000e+03
#define CFGBBearing9x 3.0000000000000000e+00
#define CFGBBearing9y 3.0000000000000000e+00
#define CFGBBearing9z 3.0000000000000000e+00
#define KMGBBearing9y 1.0000000000000000e+03
#define KMGBBearing9z 1.0000000000000000e+03
#define CMGBBearing9y 3.0000000000000000e+00
#define CMGBBearing9z 3.0000000000000000e+00
#define KM56x 1.0000000000000000e+03
#define KM56y 1.0000000000000000e+03
#define KM56z 1.0000000000000000e+03
#define CM56x 3.0000000000000000e+00
#define CM56y 3.0000000000000000e+00
#define CM56z 3.0000000000000000e+00
#define KFGBBearing5x 1.0000000000000000e+03
#define KFGBBearing5y 1.0000000000000000e+03
#define KFGBBearing5z 1.0000000000000000e+03
#define CFGBBearing5x 3.0000000000000000e+00
#define CFGBBearing5y 3.0000000000000000e+00
#define CFGBBearing5z 3.0000000000000000e+00
#define KMGBBearing5y 1.0000000000000000e+03
#define KMGBBearing5z 1.0000000000000000e+03
#define CMGBBearing5y 3.0000000000000000e+00
#define CMGBBearing5z 3.0000000000000000e+00
#define KFGBBearing6x 1.0000000000000000e+03
#define KFGBBearing6y 1.0000000000000000e+03
#define KFGBBearing6z 1.0000000000000000e+03
#define CFGBBearing6x 3.0000000000000000e+00
#define CFGBBearing6y 3.0000000000000000e+00
#define CFGBBearing6z 3.0000000000000000e+00
#define KMGBBearing6y 1.0000000000000000e+03
#define KMGBBearing6z 1.0000000000000000e+03
#define CMGBBearing6y 3.0000000000000000e+00
#define CMGBBearing6z 3.0000000000000000e+00
#define KFGBBearing1x 1.0000000000000000e+03
#define KFGBBearing1y 1.0000000000000000e+03
#define KFGBBearing1z 1.0000000000000000e+03
#define CFGBBearing1x 3.0000000000000000e+00
#define CFGBBearing1y 3.0000000000000000e+00
#define CFGBBearing1z 3.0000000000000000e+00
#define KMGBBearing1y 1.0000000000000000e+03
#define KMGBBearing1z 1.0000000000000000e+03
#define CMGBBearing1y 3.0000000000000000e+00
#define CMGBBearing1z 3.0000000000000000e+00
#define KFGBBearing2x 1.0000000000000000e+03
#define KFGBBearing2y 1.0000000000000000e+03
#define KFGBBearing2z 1.0000000000000000e+03
#define CFGBBearing2x 3.0000000000000000e+00
#define CFGBBearing2y 3.0000000000000000e+00
#define CFGBBearing2z 3.0000000000000000e+00
#define KMGBBearing2y 1.0000000000000000e+03
#define KMGBBearing2z 1.0000000000000000e+03
#define CMGBBearing2y 3.0000000000000000e+00
#define CMGBBearing2z 3.0000000000000000e+00
#define KFGBBearing3x 1.0000000000000000e+03
#define KFGBBearing3y 1.0000000000000000e+03
#define KFGBBearing3z 1.0000000000000000e+03
#define CFGBBearing3x 3.0000000000000000e+00
#define CFGBBearing3y 3.0000000000000000e+00
#define CFGBBearing3z 3.0000000000000000e+00
#define KMGBBearing3y 1.0000000000000000e+03
#define KMGBBearing3z 1.0000000000000000e+03
#define CMGBBearing3y 3.0000000000000000e+00
#define CMGBBearing3z 3.0000000000000000e+00
#define KFGBBearing7x 1.0000000000000000e+03
#define KFGBBearing7y 1.0000000000000000e+03
#define KFGBBearing7z 1.0000000000000000e+03
#define CFGBBearing7x 3.0000000000000000e+00
#define CFGBBearing7y 3.0000000000000000e+00
#define CFGBBearing7z 3.0000000000000000e+00
#define KMGBBearing7y 1.0000000000000000e+03
#define KMGBBearing7z 1.0000000000000000e+03
#define CMGBBearing7y 3.0000000000000000e+00
#define CMGBBearing7z 3.0000000000000000e+00
#define KFGBBearing8x 1.0000000000000000e+03
#define KFGBBearing8y 1.0000000000000000e+03
#define KFGBBearing8z 1.0000000000000000e+03
#define CFGBBearing8x 3.0000000000000000e+00
#define CFGBBearing8y 3.0000000000000000e+00
#define CFGBBearing8z 3.0000000000000000e+00
#define KMGBBearing8y 1.0000000000000000e+03
#define KMGBBearing8z 1.0000000000000000e+03
#define CMGBBearing8y 3.0000000000000000e+00
#define CMGBBearing8z 3.0000000000000000e+00

double * param=NULL; 

void Init_param_values ( void )
{
param[0]=g;
param[1]=L2x;
param[2]=L2z;
param[3]=LS2x1;
param[4]=LS2y1;
param[5]=LS2z1;
param[6]=LS2x2;
param[7]=LS2x3;
param[8]=LS2y2;
param[9]=LS2y3;
param[10]=LS2z2;
param[11]=LB2x;
param[12]=LB2y;
param[13]=LB2z;
param[14]=b2;
param[15]=L3x1;
param[16]=L3x2;
param[17]=L4x;
param[18]=L4y;
param[19]=L4z;
param[20]=LS4x;
param[21]=LS4y;
param[22]=LS4z;
param[23]=L6x;
param[24]=LB5x;
param[25]=LB5y;
param[26]=LS7x1;
param[27]=LS7x2;
param[28]=LS7y1;
param[29]=LS7y2;
param[30]=LS7z;
param[31]=LGx1;
param[32]=LGx2;
param[33]=LGx3;
param[34]=LGx4;
param[35]=LGx5;
param[36]=LGx6;
param[37]=LGx7;
param[38]=LGx8;
param[39]=LGr1;
param[40]=LGy1;
param[41]=LGz1;
param[42]=LGy2;
param[43]=LGz2;
param[44]=Z_Ring;
param[45]=Z_Sun;
param[46]=Z_Pla;
param[47]=Z_SecSt1;
param[48]=Z_SecSt2;
param[49]=Z_ThiSt1;
param[50]=Z_ThiSt2;
param[51]=m2;
param[52]=mx2;
param[53]=my2;
param[54]=mz2;
param[55]=Ixx2;
param[56]=Ixy2;
param[57]=Iyy2;
param[58]=Ixz2;
param[59]=Izz2;
param[60]=Iyz2;
param[61]=m3;
param[62]=mx3;
param[63]=my3;
param[64]=mz3;
param[65]=Ixx3;
param[66]=Ixy3;
param[67]=Iyy3;
param[68]=Ixz3;
param[69]=Izz3;
param[70]=Iyz3;
param[71]=m4;
param[72]=mx4;
param[73]=my4;
param[74]=mz4;
param[75]=Ixx4;
param[76]=Ixy4;
param[77]=Iyy4;
param[78]=Ixz4;
param[79]=Izz4;
param[80]=Iyz4;
param[81]=m5;
param[82]=mx5;
param[83]=my5;
param[84]=mz5;
param[85]=Ixx5;
param[86]=Ixy5;
param[87]=Iyy5;
param[88]=Ixz5;
param[89]=Izz5;
param[90]=Iyz5;
param[91]=m6;
param[92]=mx6;
param[93]=my6;
param[94]=mz6;
param[95]=Ixx6;
param[96]=Ixy6;
param[97]=Iyy6;
param[98]=Ixz6;
param[99]=Izz6;
param[100]=Iyz6;
param[101]=m7;
param[102]=mx7;
param[103]=my7;
param[104]=mz7;
param[105]=Ixx7;
param[106]=Ixy7;
param[107]=Iyy7;
param[108]=Ixz7;
param[109]=Izz7;
param[110]=Iyz7;
param[111]=mSun;
param[112]=mxSun;
param[113]=mySun;
param[114]=mzSun;
param[115]=IxxSun;
param[116]=IxySun;
param[117]=IyySun;
param[118]=IxzSun;
param[119]=IzzSun;
param[120]=IyzSun;
param[121]=mPla1;
param[122]=mxPla1;
param[123]=myPla1;
param[124]=mzPla1;
param[125]=IxxPla1;
param[126]=IxyPla1;
param[127]=IyyPla1;
param[128]=IxzPla1;
param[129]=IzzPla1;
param[130]=IyzPla1;
param[131]=mPla2;
param[132]=mxPla2;
param[133]=myPla2;
param[134]=mzPla2;
param[135]=IxxPla2;
param[136]=IxyPla2;
param[137]=IyyPla2;
param[138]=IxzPla2;
param[139]=IzzPla2;
param[140]=IyzPla2;
param[141]=mPla3;
param[142]=mxPla3;
param[143]=myPla3;
param[144]=mzPla3;
param[145]=IxxPla3;
param[146]=IxyPla3;
param[147]=IyyPla3;
param[148]=IxzPla3;
param[149]=IzzPla3;
param[150]=IyzPla3;
param[151]=mSecSt;
param[152]=mxSecSt;
param[153]=mySecSt;
param[154]=mzSecSt;
param[155]=IxxSecSt;
param[156]=IxySecSt;
param[157]=IyySecSt;
param[158]=IxzSecSt;
param[159]=IzzSecSt;
param[160]=IyzSecSt;
param[161]=KF12x;
param[162]=KF12y;
param[163]=CF12x;
param[164]=CF12y;
param[165]=KM12z;
param[166]=CM12z;
param[167]=KF24x;
param[168]=KF24y;
param[169]=KF24z;
param[170]=CF24x;
param[171]=CF24y;
param[172]=CF24z;
param[173]=KF27x;
param[174]=KF27y;
param[175]=KF27z;
param[176]=CF27x;
param[177]=CF27y;
param[178]=CF27z;
param[179]=KFBearing1x;
param[180]=KFBearing1y;
param[181]=KFBearing1z;
param[182]=CFBearing1x;
param[183]=CFBearing1y;
param[184]=CFBearing1z;
param[185]=KMBearing1y;
param[186]=KMBearing1z;
param[187]=CMBearing1y;
param[188]=CMBearing1z;
param[189]=KFBearing2x;
param[190]=KFBearing2y;
param[191]=KFBearing2z;
param[192]=CFBearing2x;
param[193]=CFBearing2y;
param[194]=CFBearing2z;
param[195]=KMBearing2y;
param[196]=KMBearing2z;
param[197]=CMBearing2y;
param[198]=CMBearing2z;
param[199]=KFGBBearing4x;
param[200]=KFGBBearing4y;
param[201]=KFGBBearing4z;
param[202]=CFGBBearing4x;
param[203]=CFGBBearing4y;
param[204]=CFGBBearing4z;
param[205]=KMGBBearing4y;
param[206]=KMGBBearing4z;
param[207]=CMGBBearing4y;
param[208]=CMGBBearing4z;
param[209]=KFBearing3x;
param[210]=KFBearing3y;
param[211]=KFBearing3z;
param[212]=CFBearing3x;
param[213]=CFBearing3y;
param[214]=CFBearing3z;
param[215]=KMBearing3y;
param[216]=KMBearing3z;
param[217]=CMBearing3y;
param[218]=CMBearing3z;
param[219]=KFGBBearing9x;
param[220]=KFGBBearing9y;
param[221]=KFGBBearing9z;
param[222]=CFGBBearing9x;
param[223]=CFGBBearing9y;
param[224]=CFGBBearing9z;
param[225]=KMGBBearing9y;
param[226]=KMGBBearing9z;
param[227]=CMGBBearing9y;
param[228]=CMGBBearing9z;
param[229]=KM56x;
param[230]=KM56y;
param[231]=KM56z;
param[232]=CM56x;
param[233]=CM56y;
param[234]=CM56z;
param[235]=KFGBBearing5x;
param[236]=KFGBBearing5y;
param[237]=KFGBBearing5z;
param[238]=CFGBBearing5x;
param[239]=CFGBBearing5y;
param[240]=CFGBBearing5z;
param[241]=KMGBBearing5y;
param[242]=KMGBBearing5z;
param[243]=CMGBBearing5y;
param[244]=CMGBBearing5z;
param[245]=KFGBBearing6x;
param[246]=KFGBBearing6y;
param[247]=KFGBBearing6z;
param[248]=CFGBBearing6x;
param[249]=CFGBBearing6y;
param[250]=CFGBBearing6z;
param[251]=KMGBBearing6y;
param[252]=KMGBBearing6z;
param[253]=CMGBBearing6y;
param[254]=CMGBBearing6z;
param[255]=KFGBBearing1x;
param[256]=KFGBBearing1y;
param[257]=KFGBBearing1z;
param[258]=CFGBBearing1x;
param[259]=CFGBBearing1y;
param[260]=CFGBBearing1z;
param[261]=KMGBBearing1y;
param[262]=KMGBBearing1z;
param[263]=CMGBBearing1y;
param[264]=CMGBBearing1z;
param[265]=KFGBBearing2x;
param[266]=KFGBBearing2y;
param[267]=KFGBBearing2z;
param[268]=CFGBBearing2x;
param[269]=CFGBBearing2y;
param[270]=CFGBBearing2z;
param[271]=KMGBBearing2y;
param[272]=KMGBBearing2z;
param[273]=CMGBBearing2y;
param[274]=CMGBBearing2z;
param[275]=KFGBBearing3x;
param[276]=KFGBBearing3y;
param[277]=KFGBBearing3z;
param[278]=CFGBBearing3x;
param[279]=CFGBBearing3y;
param[280]=CFGBBearing3z;
param[281]=KMGBBearing3y;
param[282]=KMGBBearing3z;
param[283]=CMGBBearing3y;
param[284]=CMGBBearing3z;
param[285]=KFGBBearing7x;
param[286]=KFGBBearing7y;
param[287]=KFGBBearing7z;
param[288]=CFGBBearing7x;
param[289]=CFGBBearing7y;
param[290]=CFGBBearing7z;
param[291]=KMGBBearing7y;
param[292]=KMGBBearing7z;
param[293]=CMGBBearing7y;
param[294]=CMGBBearing7z;
param[295]=KFGBBearing8x;
param[296]=KFGBBearing8y;
param[297]=KFGBBearing8z;
param[298]=CFGBBearing8x;
param[299]=CFGBBearing8y;
param[300]=CFGBBearing8z;
param[301]=KMGBBearing8y;
param[302]=KMGBBearing8z;
param[303]=CMGBBearing8y;
param[304]=CMGBBearing8z;
}

void Init_param ( )
{
 param = malloc ( n_param * sizeof(double) );
 {int i;
  for ( i = 0 ; i < n_param ; i++ ) {param[i]=0.0;}
 }
}

void Done_param( ) 
{
if ( param != NULL) 
free ( param ); 
param = NULL; 
}

void Reallocate_param( double * user_param ) 
{
param = user_param; 
}

