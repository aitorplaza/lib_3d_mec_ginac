/*----------param.h lib3D_MEC expoted-----------*/

extern double * param;
extern void Init_param_values ( void );
extern void Init_param ( void );
extern void Done_param( void );
extern void Reallocate_param( double * user_param );

#define n_param 305
