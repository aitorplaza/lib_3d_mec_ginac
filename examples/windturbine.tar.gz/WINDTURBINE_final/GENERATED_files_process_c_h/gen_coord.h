/*----------gen_coord.h lib3D_MEC expoted-----------*/

extern double * q;
extern void Init_q_values ( void );
extern void Init_q ( void );
extern void Done_q( void );
extern void Reallocate_q( double * user_q );

#define n_gen_coord 55
