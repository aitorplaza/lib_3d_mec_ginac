/*----------gen_accel.h lib3D_MEC expoted-----------*/

extern double * ddq;
extern void Init_ddq_values ( void );
extern void Init_ddq ( void );
extern void Done_ddq( void );
extern void Reallocate_ddq( double * user_ddq );

#define n_gen_accel 55
