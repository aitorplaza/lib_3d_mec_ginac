/*{*/
  double t1;
  double t2;
  /*{*/
    _Output[0] = a3;
    _Output[1] = a5;
    _Output[2] = da3;
    _Output[3] = da5;
    t1 = pow(a3,-0.1E1);
    _Output[4] = t1*a5;
    t2 = pow(da3,-0.1E1);
    _Output[5] = da5*t2;
   /*}*/
 /*}*/

