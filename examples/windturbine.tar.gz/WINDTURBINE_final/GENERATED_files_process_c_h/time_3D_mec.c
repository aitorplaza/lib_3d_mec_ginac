/*----------time_3D_mec.c lib3D_MEC expoted-----------*/

#include <math.h>
#include "time_3D_mec.h"
/*----------time-----------*/

double t;

void Init_t ( void )
{
t = 0.0;
}
