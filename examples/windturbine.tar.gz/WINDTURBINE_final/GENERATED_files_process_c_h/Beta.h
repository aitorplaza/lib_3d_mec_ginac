#define Beta_n_rows 6
#define Beta_n_cols 1
extern double * _Beta;
extern void Init_Beta ( ); 
extern void Done_Beta ( ); 
extern double * Beta ( ) ;
