#define M_n_rows 55
#define M_n_cols 55
extern double * _M;
extern void Init_M ( ); 
extern void Done_M ( ); 
extern double * M ( ) ;
