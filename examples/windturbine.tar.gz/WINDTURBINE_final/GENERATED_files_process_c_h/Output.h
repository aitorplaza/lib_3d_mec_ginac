#define Output_n_rows 6
#define Output_n_cols 1
extern double * _Output;
extern void Init_Output ( ); 
extern void Done_Output ( ); 
extern double * Output ( ) ;
