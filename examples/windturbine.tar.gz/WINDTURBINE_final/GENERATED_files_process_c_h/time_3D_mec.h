/*----------time_3D_mec.h lib3D_MEC exported-----------*/

/*----------time-----------*/

extern double t;
extern void Init_t ( void );

