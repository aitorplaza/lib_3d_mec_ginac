#define PhiInit_q_n_rows 55
#define PhiInit_q_n_cols 55
extern double * _PhiInit_q;
extern void Init_PhiInit_q ( ); 
extern void Done_PhiInit_q ( ); 
extern double * PhiInit_q ( ) ;
