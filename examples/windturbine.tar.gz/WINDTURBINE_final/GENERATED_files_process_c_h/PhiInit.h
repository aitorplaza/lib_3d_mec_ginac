#define PhiInit_n_rows 55
#define PhiInit_n_cols 1
extern double * _PhiInit;
extern void Init_PhiInit ( ); 
extern void Done_PhiInit ( ); 
extern double * PhiInit ( ) ;
