#define Phi_q_n_rows 6
#define Phi_q_n_cols 55
extern double * _Phi_q;
extern void Init_Phi_q ( ); 
extern void Done_Phi_q ( ); 
extern double * Phi_q ( ) ;
