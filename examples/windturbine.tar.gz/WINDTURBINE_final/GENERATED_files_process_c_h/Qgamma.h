#define Qgamma_n_rows 61
#define Qgamma_n_cols 1
extern double * _Qgamma;
extern void Init_Qgamma ( ); 
extern void Done_Qgamma ( ); 
extern double * Qgamma ( ) ;
