#define BetaInit_n_rows 55
#define BetaInit_n_cols 1
extern double * _BetaInit;
extern void Init_BetaInit ( ); 
extern void Done_BetaInit ( ); 
extern double * BetaInit ( ) ;
