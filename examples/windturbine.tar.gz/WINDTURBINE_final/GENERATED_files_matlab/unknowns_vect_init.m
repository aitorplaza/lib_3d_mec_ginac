global lambda1;
global lambda2;
global lambda3;
global lambda4;
global lambda5;
global lambda6;
global unknowns;
unknowns=[lambda1,lambda2,lambda3,lambda4,lambda5,lambda6]';
