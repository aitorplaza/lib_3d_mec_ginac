global t;
t = 0.0;
