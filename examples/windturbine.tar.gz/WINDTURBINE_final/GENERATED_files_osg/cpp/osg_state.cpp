#ifndef __linux__
  #include <windows.h>
#endif

#include <osg/Geode>
#include <osg/Material>
#include <osg/BlendFunc>

#include "osg_read_file.h"

void osg_state ()
{

osg::StateSet* State_R2 = Sol_R2->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialR2 = new osg::Material;
materialR2->setDiffuse(osg::Material::FRONT,osg::Vec4(1.0,0.0,0.0,1.0));
State_R2->setAttributeAndModes( materialR2.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_R2->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_R2->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_R3 = Sol_R3->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialR3 = new osg::Material;
materialR3->setDiffuse(osg::Material::FRONT,osg::Vec4(0.0,1.0,0.0,1.0));
State_R3->setAttributeAndModes( materialR3.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_R3->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_R3->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_R4 = Sol_R4->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialR4 = new osg::Material;
materialR4->setDiffuse(osg::Material::FRONT,osg::Vec4(1.0,1.0,0.0,1.0));
State_R4->setAttributeAndModes( materialR4.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_R4->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_R4->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_R5 = Sol_R5->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialR5 = new osg::Material;
materialR5->setDiffuse(osg::Material::FRONT,osg::Vec4(1.0,0.0,1.0,1.0));
State_R5->setAttributeAndModes( materialR5.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_R5->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_R5->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_R6 = Sol_R6->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialR6 = new osg::Material;
materialR6->setDiffuse(osg::Material::FRONT,osg::Vec4(0.0,1.0,0.0,1.0));
State_R6->setAttributeAndModes( materialR6.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_R6->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_R6->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_R7 = Sol_R7->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialR7 = new osg::Material;
materialR7->setDiffuse(osg::Material::FRONT,osg::Vec4(0.0,0.0,1.0,1.0));
State_R7->setAttributeAndModes( materialR7.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_R7->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_R7->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_RSun = Sol_RSun->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialRSun = new osg::Material;
materialRSun->setDiffuse(osg::Material::FRONT,osg::Vec4(1.0,0.4000000000000000222,0.4000000000000000222,1.0));
State_RSun->setAttributeAndModes( materialRSun.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_RSun->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_RSun->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_RPla1 = Sol_RPla1->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialRPla1 = new osg::Material;
materialRPla1->setDiffuse(osg::Material::FRONT,osg::Vec4(0.4000000000000000222,0.8000000000000000444,0.8000000000000000444,1.0));
State_RPla1->setAttributeAndModes( materialRPla1.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_RPla1->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_RPla1->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_RPla2 = Sol_RPla2->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialRPla2 = new osg::Material;
materialRPla2->setDiffuse(osg::Material::FRONT,osg::Vec4(0.4000000000000000222,0.8000000000000000444,0.8000000000000000444,1.0));
State_RPla2->setAttributeAndModes( materialRPla2.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_RPla2->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_RPla2->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_RPla3 = Sol_RPla3->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialRPla3 = new osg::Material;
materialRPla3->setDiffuse(osg::Material::FRONT,osg::Vec4(0.4000000000000000222,0.8000000000000000444,0.8000000000000000444,1.0));
State_RPla3->setAttributeAndModes( materialRPla3.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_RPla3->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_RPla3->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

osg::StateSet* State_RSecSt = Sol_RSecSt->getOrCreateStateSet();
osg::ref_ptr<osg::Material> materialRSecSt = new osg::Material;
materialRSecSt->setDiffuse(osg::Material::FRONT,osg::Vec4(0.4000000000000000222,0.5999999999999999778,0.2000000000000000111,1.0));
State_RSecSt->setAttributeAndModes( materialRSecSt.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
State_RSecSt->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
State_RSecSt->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA));

}
