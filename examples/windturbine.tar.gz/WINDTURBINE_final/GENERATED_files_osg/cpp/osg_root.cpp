#ifndef __linux__
  #include <windows.h>
#endif
 
#include <osg/Group>
#include <osg/Geode>
#include <osg/MatrixTransform>
 
#include "solids_homogeneous_matrix.h"
#include "osg_read_file.h"
#include "osg_state.h"

osg::MatrixTransform* MTrans_Sol_R2;
osg::MatrixTransform* MTrans_Sol_R3;
osg::MatrixTransform* MTrans_Sol_R4;
osg::MatrixTransform* MTrans_Sol_R5;
osg::MatrixTransform* MTrans_Sol_R6;
osg::MatrixTransform* MTrans_Sol_R7;
osg::MatrixTransform* MTrans_Sol_RSun;
osg::MatrixTransform* MTrans_Sol_RPla1;
osg::MatrixTransform* MTrans_Sol_RPla2;
osg::MatrixTransform* MTrans_Sol_RPla3;
osg::MatrixTransform* MTrans_Sol_RSecSt;

osg::Group* Sol_R2_axis;
osg::Group* Sol_R3_axis;
osg::Group* Sol_R4_axis;
osg::Group* Sol_R5_axis;
osg::Group* Sol_R6_axis;
osg::Group* Sol_R7_axis;
osg::Group* Sol_RSun_axis;
osg::Group* Sol_RPla1_axis;
osg::Group* Sol_RPla2_axis;
osg::Group* Sol_RPla3_axis;
osg::Group* Sol_RSecSt_axis;

osg::Group* root;

void osg_root ()
{
osg_state();

Sol_R2_axis = new osg::Group;
Sol_R2_axis->addChild(Sol_R2);
Sol_R2_axis->addChild(axis);
MTrans_Sol_R2 = new osg::MatrixTransform(MSol_R2);
MTrans_Sol_R2->addChild(Sol_R2_axis);
	
Sol_R3_axis = new osg::Group;
Sol_R3_axis->addChild(Sol_R3);
Sol_R3_axis->addChild(axis);
MTrans_Sol_R3 = new osg::MatrixTransform(MSol_R3);
MTrans_Sol_R3->addChild(Sol_R3_axis);
	
Sol_R4_axis = new osg::Group;
Sol_R4_axis->addChild(Sol_R4);
Sol_R4_axis->addChild(axis);
MTrans_Sol_R4 = new osg::MatrixTransform(MSol_R4);
MTrans_Sol_R4->addChild(Sol_R4_axis);
	
Sol_R5_axis = new osg::Group;
Sol_R5_axis->addChild(Sol_R5);
Sol_R5_axis->addChild(axis);
MTrans_Sol_R5 = new osg::MatrixTransform(MSol_R5);
MTrans_Sol_R5->addChild(Sol_R5_axis);
	
Sol_R6_axis = new osg::Group;
Sol_R6_axis->addChild(Sol_R6);
Sol_R6_axis->addChild(axis);
MTrans_Sol_R6 = new osg::MatrixTransform(MSol_R6);
MTrans_Sol_R6->addChild(Sol_R6_axis);
	
Sol_R7_axis = new osg::Group;
Sol_R7_axis->addChild(Sol_R7);
Sol_R7_axis->addChild(axis);
MTrans_Sol_R7 = new osg::MatrixTransform(MSol_R7);
MTrans_Sol_R7->addChild(Sol_R7_axis);
	
Sol_RSun_axis = new osg::Group;
Sol_RSun_axis->addChild(Sol_RSun);
Sol_RSun_axis->addChild(axis);
MTrans_Sol_RSun = new osg::MatrixTransform(MSol_RSun);
MTrans_Sol_RSun->addChild(Sol_RSun_axis);
	
Sol_RPla1_axis = new osg::Group;
Sol_RPla1_axis->addChild(Sol_RPla1);
Sol_RPla1_axis->addChild(axis);
MTrans_Sol_RPla1 = new osg::MatrixTransform(MSol_RPla1);
MTrans_Sol_RPla1->addChild(Sol_RPla1_axis);
	
Sol_RPla2_axis = new osg::Group;
Sol_RPla2_axis->addChild(Sol_RPla2);
Sol_RPla2_axis->addChild(axis);
MTrans_Sol_RPla2 = new osg::MatrixTransform(MSol_RPla2);
MTrans_Sol_RPla2->addChild(Sol_RPla2_axis);
	
Sol_RPla3_axis = new osg::Group;
Sol_RPla3_axis->addChild(Sol_RPla3);
Sol_RPla3_axis->addChild(axis);
MTrans_Sol_RPla3 = new osg::MatrixTransform(MSol_RPla3);
MTrans_Sol_RPla3->addChild(Sol_RPla3_axis);
	
Sol_RSecSt_axis = new osg::Group;
Sol_RSecSt_axis->addChild(Sol_RSecSt);
Sol_RSecSt_axis->addChild(axis);
MTrans_Sol_RSecSt = new osg::MatrixTransform(MSol_RSecSt);
MTrans_Sol_RSecSt->addChild(Sol_RSecSt_axis);
	
	
root = new osg::Group;
root->addChild(MTrans_Sol_R2);
root->addChild(MTrans_Sol_R3);
root->addChild(MTrans_Sol_R4);
root->addChild(MTrans_Sol_R5);
root->addChild(MTrans_Sol_R6);
root->addChild(MTrans_Sol_R7);
root->addChild(MTrans_Sol_RSun);
root->addChild(MTrans_Sol_RPla1);
root->addChild(MTrans_Sol_RPla2);
root->addChild(MTrans_Sol_RPla3);
root->addChild(MTrans_Sol_RSecSt);
}
