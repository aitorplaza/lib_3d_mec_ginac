#ifndef __linux__
  #include <windows.h>
#endif
 
#include <osg/Geode>
#include <osgDB/ReadFile>
 
osg::Geode* axis;
osg::Geode* Sol_R2;
osg::Geode* Sol_R3;
osg::Geode* Sol_R4;
osg::Geode* Sol_R5;
osg::Geode* Sol_R6;
osg::Geode* Sol_R7;
osg::Geode* Sol_RSun;
osg::Geode* Sol_RPla1;
osg::Geode* Sol_RPla2;
osg::Geode* Sol_RPla3;
osg::Geode* Sol_RSecSt;
 
void osg_read_file ()
{
Sol_R2 = (osg::Geode*) osgDB::readNodeFile("./solids/SolR2.stl.[1].scale");
Sol_R3 = (osg::Geode*) osgDB::readNodeFile("./solids/SolR3.stl.[1].scale");
Sol_R4 = (osg::Geode*) osgDB::readNodeFile("./solids/SolR4.stl.[1].scale");
Sol_R5 = (osg::Geode*) osgDB::readNodeFile("./solids/SolR5.stl.[1].scale");
Sol_R6 = (osg::Geode*) osgDB::readNodeFile("./solids/SolR6.stl.[1].scale");
Sol_R7 = (osg::Geode*) osgDB::readNodeFile("./solids/SolR7.stl.[1].scale");
Sol_RSun = (osg::Geode*) osgDB::readNodeFile("./solids/SolRSun.stl.[1].scale");
Sol_RPla1 = (osg::Geode*) osgDB::readNodeFile("./solids/SolRPla1.stl.[1].scale");
Sol_RPla2 = (osg::Geode*) osgDB::readNodeFile("./solids/SolRPla2.stl.[1].scale");
Sol_RPla3 = (osg::Geode*) osgDB::readNodeFile("./solids/SolRPla3.stl.[1].scale");
Sol_RSecSt = (osg::Geode*) osgDB::readNodeFile("./solids/SolRSecSt.stl.[1].scale");
}
