extern void osg_root ( void );
	
extern osg::MatrixTransform* MTrans_Sol_R2;
extern osg::Group* Sol_R2_axis;
	
extern osg::MatrixTransform* MTrans_Sol_R3;
extern osg::Group* Sol_R3_axis;
	
extern osg::MatrixTransform* MTrans_Sol_R4;
extern osg::Group* Sol_R4_axis;
	
extern osg::MatrixTransform* MTrans_Sol_R5;
extern osg::Group* Sol_R5_axis;
	
extern osg::MatrixTransform* MTrans_Sol_R6;
extern osg::Group* Sol_R6_axis;
	
extern osg::MatrixTransform* MTrans_Sol_R7;
extern osg::Group* Sol_R7_axis;
	
extern osg::MatrixTransform* MTrans_Sol_RSun;
extern osg::Group* Sol_RSun_axis;
	
extern osg::MatrixTransform* MTrans_Sol_RPla1;
extern osg::Group* Sol_RPla1_axis;
	
extern osg::MatrixTransform* MTrans_Sol_RPla2;
extern osg::Group* Sol_RPla2_axis;
	
extern osg::MatrixTransform* MTrans_Sol_RPla3;
extern osg::Group* Sol_RPla3_axis;
	
extern osg::MatrixTransform* MTrans_Sol_RSecSt;
extern osg::Group* Sol_RSecSt_axis;
	
extern osg::Group* root;
