extern void osg_state ( void );
 
extern osg::StateSet* state;
