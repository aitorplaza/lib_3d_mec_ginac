#include "VectorE.h"
#include "System.h"
#include "Globals.h"
#include "Vector3D.h"
#include <vector>

using namespace std;

// Definición:
template <class T>
VectorE<T>::VectorE( void ) {
   vector<T> vT;
}



//~ void Drawing3D::init ( string name, string type, Point * point , Base * base){
	//~ this-> name = name;
	//~ this-> type = type;
	//~ this-> P = point;
	//~ this-> B = base;
	//~ this-> file = "";
	//~ //this-> color = 0,0,0,1;
	//~ this-> color = 9 ,9 ,9 ,9 ;
	//~ this-> scale = 1;
//~ }

/*
General DRAWING3D constructor
*/
//~ Drawing3D::Drawing3D ( void ){
	//~ init ( "" ,"", NULL , NULL);
//~ 
//~ }

/*
DRAWING3 constructor
*/		
//~ Drawing3D::Drawing3D ( string name, string type, Point * P , Base * B){
        //~ init ( name, type, P , B);
//~ }

/*
Return the name
*/
//~ string VectorE::get_name ( void ){	
	//~ return name;   
//~ }




template <class T>
void VectorE<T>::push (T const& elem) 
{ 
    // append copy of passed element 
    Velems.push_back(elem);    
}










/*
Destructor
*/
template <class T>
VectorE<T>::~VectorE( void ) {
   //delete
}

