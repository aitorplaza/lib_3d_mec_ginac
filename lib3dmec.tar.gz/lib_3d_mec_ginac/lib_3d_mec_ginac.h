#include "Matrix.h"
#include "Vector3D.h"
#include "atom.h"
#include "symbol_numeric.h"
#include "Tensor3D.h"
#include "System.h"
#include "Globals.h"

#define LIB3D_MEC_GINAC_MAJOR_VERSION 1
#define LIB3D_MEC_GINAC_MINOR_VERSION 1
